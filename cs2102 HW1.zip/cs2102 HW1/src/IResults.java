public interface IResults {
    boolean isValid();
}
