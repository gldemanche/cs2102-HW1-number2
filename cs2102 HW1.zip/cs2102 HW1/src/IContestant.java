public interface IContestant {
}
